package com.patrick.service;


/**
 * 管理員service接口
 */
public interface AdminService {

/**
 * 驗證密碼是否正確
 */
    public boolean verifyPassword(String username, String password);
}

