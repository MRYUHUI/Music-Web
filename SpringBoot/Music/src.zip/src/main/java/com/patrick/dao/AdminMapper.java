package com.patrick.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AdminMapper {

    @Select("select count(*) from admin where name = #{username} and password = #{pwd}")
    public int verifyPassword(String username, String pwd);
}
