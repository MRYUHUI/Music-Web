package com.patrick.controller;

import com.alibaba.fastjson.JSONObject;
import com.patrick.domain.SongList;
import com.patrick.domain.UserCreateSongList;
import com.patrick.service.SongListService;
import com.patrick.service.UserCreateSongListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static com.patrick.utils.Consts.DATA;
import static com.patrick.utils.Consts.getJson;

/**
 * @Author:
 * @Date: 2024-04-14-15:44
 * @Description:
 */
@RestController
@RequestMapping("/myspace")
public class MySpaceController {
    @Autowired
    UserCreateSongListService userCreateSongListService;
    @Autowired
    SongListService songListService;

    @PostMapping("/add")
    public Object insert(@RequestBody UserCreateSongList userCreateSongList) {
        boolean flag = userCreateSongListService.insert(userCreateSongList);
        return getJson(flag, "收藏");
    }

    @PostMapping("/is_exist")
    public Object isExist(@RequestBody UserCreateSongList userCreateSongList) {
        boolean flag =  userCreateSongListService.isExist(userCreateSongList);
        JSONObject json = getJson(flag, "删除");
        json.put(DATA, flag);
        return json;
    }
    @PostMapping("/delete")
    public Object delete(@RequestBody UserCreateSongList userCreateSongList) {
        boolean flag = userCreateSongListService.delete(userCreateSongList);
        JSONObject json = getJson(flag, "删除");
        json.put(DATA, flag);
        return json;
    }
    @GetMapping("/playlist")
    public Object getConsumerByUsername(@RequestParam Integer id) {
        List<Integer> playListIds = userCreateSongListService.getPlaylistIdsByUserId(id);
        List<SongList> songLists = new ArrayList<>();
        for (int playListId : playListIds) {
            songLists.add(songListService.getSongListById(playListId));
        }
        JSONObject jsonObject = getJson(true, "获取");
        jsonObject.put(DATA, songLists);
        return jsonObject;
    }


}
